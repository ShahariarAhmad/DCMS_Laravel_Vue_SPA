<template>
   <div class="grid grid-cols-12">
    <side-bar></side-bar>

        <div class="col-span-8 p-5 ">

            <div class="grid grid-cols-1  shadow-2xl p-5 rounded-2xl my-5 border border-gray-400">

             
                <table class="table-auto text-center">
                    <caption class="text-xl mb-5 ">Payment History</caption>

                    <thead>
                        <tr>
                            <th>
                                #
                            </th>
                            <th>
                                Name
                            </th>
                            <th>
                                Trix ID
                            </th>
                            <th>
                                Date
                            </th>
                            <th>
                                Amout
                            </th>
                            <th>
                                Payment Method
                            </th>
                            <th>
                                Payment Stats
                            </th>
                            <th>
                                Cause
                            </th>
                            <th>
                                Handled By
                            </th>
                      
                        </tr>
                    </thead>
                    <tbody>

                        <tr>
                            <td class="px-6 py-3">
                                1
                            </td>
                            <td class="px-6 py-3">
                                সুলতানা
                            </td>
                            <td class="px-6 py-3">
                                5M414P1C01
                            </td>
                            <td class="px-6 py-3">
                                সুলতানা
                            </td>
                            <td class="px-6 py-3">
                                500
                            </td>
                            <td class="px-6 py-3">
                                nagad
                            </td>

                            <td class="px-6 py-3">
                                <span class="bg-green-200 p-2 rounded-lg">
                                    confirmed
                                </span>
                            </td>

                            <td class="px-6 py-3">
                                diet
                            </td>
                            <td class="px-6 py-3">
                                মিস্টার
                            </td>
                        </tr>
                
                        <tr>
                            <td class="px-6 py-3">
                                4
                            </td>
                            <td class="px-6 py-3">
                                সুলতানা
                            </td>
                            <td class="px-6 py-3">
                                5M414P1C04
                            </td>
                            <td class="px-6 py-3">
                                সুলতানা
                            </td>
                            <td class="px-6 py-3">
                                500
                            </td>
                            <td class="px-6 py-3">
                                dbbl
                            </td>

                            <td class="px-6 py-3">
                                <span class="badge bg-primary p-2">
                                    pending
                                </span>
                            </td>

                            <td class="px-6 py-3">
                                diet
                            </td>
                            <td class="px-6 py-3">
                                মিস্টার
                            </td>
                        </tr>
               
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</template>

<script>
</script>


<style scoped>
</style>